# Another Git Practice Package
This readme is for this package called newpackage

## For Building Locally
'pyhton setup.py sdist'

